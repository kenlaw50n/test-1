

Multi (three) Tier Architecture 

 ![](https://github.com/ashydv/aws-labs/blob/master/images/ThreeTierArchitecture.png)
 
Highly Available Network Diagram 

 ![](https://github.com/ashydv/aws-labs/blob/master/images/NetworkDiagram.png)
 
The Full Application Infra Architecture

 ![](https://github.com/ashydv/aws-labs/blob/master/images/FullArchitectecture.png)
